package com.thymeleaf.project.thymeleafdemo.controller;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class helloworldcontroller {
    @RequestMapping("/showform")
    public String showform(){
        return "helloworld-form";
    }
    @RequestMapping("/processform")
    public String processform(){
        return "helloworld-forminfo.html";
    }

    @RequestMapping("/Uppercaseall")
    public String uppercaseall(HttpServletRequest req, Model model){
                            // request has form data, model will hold it

        String firstname = req.getParameter("fname").toUpperCase()  ;
        String lastname = req.getParameter("lname").toUpperCase()   ;

        String msg = "Oyeee kesa hy " + firstname + lastname;
        model.addAttribute("message", msg);

        return "helloworld-formupper.html";
    }


}
