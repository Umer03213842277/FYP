package com.thymeleaf.project.thymeleafdemo.controller;

import com.thymeleaf.project.thymeleafdemo.model.Student;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class StudentController {
    @Value("${languages}")
    private List<String> programmingLanguages;
@GetMapping("/Show-StudentForm")
    public String showstdform(Model model){

    Student std = new Student();
    model.addAttribute("nayaBacha",std);
    model.addAttribute("progListToModel",programmingLanguages);
    return "student-form";
}

    @GetMapping("/confirmation")
    public String confirmationPage( @ModelAttribute("nayaBacha") Student std){

        return "confirmation";
    }


}
