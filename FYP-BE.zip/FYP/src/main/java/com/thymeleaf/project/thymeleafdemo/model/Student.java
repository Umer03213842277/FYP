package com.thymeleaf.project.thymeleafdemo.model;

import java.util.List;

public class Student {
    String firstname, lastname, country, proglang;

    List <String> favOs;

    public List<String> getFavOs() {
        return favOs;
    }

    public void setFavOs(List<String> favOs) {
        this.favOs = favOs;
    }



    public String getProglang() {
        return proglang;
    }

    public void setProglang(String proglang) {
        this.proglang = proglang;
    }

    public Student() {
    }

    public Student(String firstname, String lastname) {
        this.firstname = firstname;
        this.lastname = lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
}
