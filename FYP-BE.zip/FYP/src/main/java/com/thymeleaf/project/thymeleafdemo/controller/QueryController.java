package com.thymeleaf.project.thymeleafdemo.controller;


import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;
import com.google.api.client.http.FileContent;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.drive.Drive;
import com.google.api.services.drive.DriveScopes;
import com.google.api.services.drive.model.File;
import com.google.api.services.drive.model.FileList;

import java.io.FileReader;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.List;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.util.Collections;
import java.util.List;

import static java.lang.Thread.sleep;


@Controller
public class QueryController {

    String query;
    private static final String APPLICATION_NAME = "Drive Quick Start";
    private static final String CREDENTIALS_FILE_PATH = "C:/Users/Computer Point/Downloads/credentials.json";
    private static final String FILE_PATH = "C:\\Users\\Computer Point\\Desktop\\file.txt";
    Drive driveService;

    @RequestMapping("/home")
    public String homePage(){
        return "index";
    }

    @RequestMapping("/sendFormRequest")
    public String sendQueryToDrive(HttpServletRequest req, Model model) throws GeneralSecurityException, IOException, InterruptedException {
        query = req.getParameter("query");

        createFile();
        sendFileToDrive();  // SENDING FILES HAS BEEN COMMITTED TO CHECK LATEST DATA COMING FROM DRIVE OR NOT.

        File latestFile = getLatestFile();

        // Get the content of the file
        String fileContent =getFileContent(latestFile.getId());

        // Pass data to Thymeleaf template
        model.addAttribute("fileName", latestFile.getName());
        model.addAttribute("fileContent", fileContent);

        System.out.println("GOT " + latestFile.getName() + "from drive.");
        return "pleasewait";
    }

    public File getLatestFile() throws IOException, GeneralSecurityException {
        try {
            sleep(20000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        driveService = initializeDriveService();
        // List files and sort them by modified time to get the latest file
        List<File> files = driveService.files().list().setOrderBy("modifiedTime desc").execute().getFiles();

        for (int i = 0; i <5; i++) {
            System.out.println(files.get(i).getName());
        }

        if (!files.isEmpty()) {
            return files.get(0);
        } else {
            throw new RuntimeException("No files found on Google Drive.");
        }
    }
    public String getFileContent(String fileId) throws IOException {

        // Read the content of a file using the Drive API
        try (InputStream inputStream = driveService.files().get(fileId).executeMediaAsInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        }

    }

    private boolean createFile() throws GeneralSecurityException, IOException {

        // Creating an instance of file
        Path path
                = Paths.get("C:\\Users\\Computer Point\\Desktop\\file.txt");
        try {
            Files.writeString(path, query,
                    StandardCharsets.UTF_8);
            return true;
        } catch (IOException e) {
            System.out.print("Invalid Path");
        }

        return false;
    }

    public void sendFileToDrive() {
        try {
            // Initialize the Drive service
             driveService = initializeDriveService();

            // Upload a file
            uploadFile(driveService, "1WKGXxuCzkLVNHcX8TPmwwuirxEXJky9l");
        } catch (IOException | GeneralSecurityException e) {
            e.printStackTrace();
        }
    }

    private static Drive initializeDriveService() throws IOException, GeneralSecurityException {
        // Load credentials
        GoogleClientSecrets secrets = GoogleClientSecrets.load(
                JacksonFactory.getDefaultInstance(),
                new FileReader(CREDENTIALS_FILE_PATH)
        );

        // Set up the Google Drive API
        return new Drive.Builder(
                GoogleNetHttpTransport.newTrustedTransport(),
                JacksonFactory.getDefaultInstance(),
                getCredentials(secrets)
        )
                .setApplicationName(APPLICATION_NAME)
                .build();
    }

    private static Credential getCredentials(GoogleClientSecrets clientSecrets) throws IOException {
        try {
            return new AuthorizationCodeInstalledApp(
                    new GoogleAuthorizationCodeFlow.Builder(
                            GoogleNetHttpTransport.newTrustedTransport(),
                            JacksonFactory.getDefaultInstance(),
                            clientSecrets,
                            Collections.singleton(DriveScopes.DRIVE_FILE)
                    ).setDataStoreFactory(new FileDataStoreFactory(new java.io.File("tokens")))
                            .setAccessType("offline")
                            .build(),
                    new LocalServerReceiver()
            ).authorize("user");
        } catch (GeneralSecurityException e) {
            throw new RuntimeException(e);
        }
    }

    private static void uploadFile(Drive driveService, String targetFolderId) throws IOException {
        // Prepare the file to be uploaded
        java.io.File fileContent = new java.io.File(FILE_PATH);
        FileContent mediaContent = new FileContent("text/plain", fileContent);

        // Create metadata for the file
        File fileMetadata = new File();
        fileMetadata.setName(fileContent.getName());
        fileMetadata.setParents(Collections.singletonList(targetFolderId));

        try {
            // Upload the file to Google Drive
            File uploadedFile = driveService.files().create(fileMetadata, mediaContent).execute();

            System.out.println("File uploaded to folder with ID '" + targetFolderId + "' - File ID: " + uploadedFile.getId());
        } catch (IOException e) {
            System.err.println("Error uploading file: " + e.getMessage());
        }
    }


}
